package br.edu.ceub;

import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final SistemaIMC sistema = new SistemaIMC();

    public static void main(String[] args) {

        int opcao = -1;
        Pessoa ultimaPessoa = null;
        boolean pessoaCadastrada = false;

        while (opcao != 0) {

            CalculadoraRecursiva.linha();
            System.out.println("      CALCULADORA DE IMC");
            CalculadoraRecursiva.linha();
            System.out.println("[1] Cadastrar Pessoa");
            System.out.println("[2] Cadastrar Atleta");
            System.out.println("[3] Calcular IMC da última pessoa cadastrada");
            System.out.println("[4] Exibir Histórico");
            System.out.println("[0] Sair");
            CalculadoraRecursiva.linha();
            System.out.print("Escolha: ");

            try {
                opcao = lerInt("opção");

                switch (opcao) {

                    case 1:
                        ultimaPessoa = cadastrarPessoa();
                        pessoaCadastrada = true;
                        System.out.println("Pessoa cadastrada com sucesso!");
                        System.out.println(ultimaPessoa.exibirPerfil());
                        break;

                    case 2:
                        ultimaPessoa = cadastrarAtleta();
                        pessoaCadastrada = true;
                        System.out.println("Atleta cadastrado com sucesso!");
                        System.out.println(ultimaPessoa.exibirPerfil());
                        break;

                    case 3:
                        if (!pessoaCadastrada || ultimaPessoa == null) {
                            System.out.println("Cadastre uma pessoa primeiro!");
                        } else {
                            sistema.processar(ultimaPessoa);
                        }
                        break;

                    case 4:
                        sistema.exibirHistorico();
                        break;

                    case 0:
                        System.out.println("Sistema encerrado.");
                        break;

                    default:
                        throw new EntradaInvalidaException("Opção inválida: " + opcao);
                }

            } catch (EntradaInvalidaException e) {
                System.out.println("[ERRO] " + e.getMessage());
            } catch (Exception e) {
                System.out.println("[ERRO] " + e.getMessage());
            }
        }

        scanner.close();
    }

    private static Pessoa cadastrarPessoa() {
        System.out.print("Nome: ");
        String nome = lerString("nome");

        System.out.print("Idade: ");
        int idade = lerInt("idade");

        System.out.print("Peso (kg): ");
        double peso = lerDouble("peso");

        System.out.print("Altura (m): ");
        double altura = lerDouble("altura");

        return new Pessoa(nome, idade, peso, altura);
    }

    private static Atleta cadastrarAtleta() {
        System.out.print("Nome: ");
        String nome = lerString("nome");

        System.out.print("Idade: ");
        int idade = lerInt("idade");

        System.out.print("Peso (kg): ");
        double peso = lerDouble("peso");

        System.out.print("Altura (m): ");
        double altura = lerDouble("altura");

        System.out.print("Modalidade: ");
        String modalidade = lerString("modalidade");

        return new Atleta(nome, idade, peso, altura, modalidade);
    }

    public static double lerDouble(String campo) {
        try {
            String linha = scanner.nextLine().trim().replace(",", ".");
            double valor = Double.parseDouble(linha);
            if (valor <= 0) {
                throw new EntradaInvalidaException(campo + " deve ser um valor positivo!");
            }
            return valor;
        } catch (NumberFormatException e) {
            throw new EntradaInvalidaException("Digite apenas números para " + campo + "!");
        }
    }

    public static int lerInt(String campo) {
        try {
            String linha = scanner.nextLine().trim();
            return Integer.parseInt(linha);
        } catch (NumberFormatException e) {
            throw new EntradaInvalidaException("Digite apenas números inteiros para " + campo + "!");
        }
    }

    public static String lerString(String campo) {
        String valor = scanner.nextLine().trim();
        if (valor.isEmpty()) {
            throw new EntradaInvalidaException("O campo " + campo + " não pode ser vazio!");
        }
        return valor;
    }
}
