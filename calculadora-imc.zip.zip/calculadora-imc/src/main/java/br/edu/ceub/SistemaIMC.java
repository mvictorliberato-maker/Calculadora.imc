package br.edu.ceub;

public class SistemaIMC {

    // Composição: SistemaIMC TEM-UM Historico
    private Historico historico = new Historico();

    public void processar(Pessoa pessoa) {
        double imc = pessoa.calcularIMC(pessoa.getPeso(), pessoa.getAltura());
        String classificacao = pessoa.classificarIMC(imc); // polimorfismo em ação

        String resultado =
                "Nome: " + pessoa.getNome()
                + "\nIMC: " + String.format("%.2f", imc)
                + "\nClassificação: " + classificacao;

        historico.adicionarRegistro(resultado);

        System.out.println("\n===== RESULTADO =====");
        System.out.println(resultado);
    }

    public void exibirHistorico() {
        historico.exibirHistorico();
    }
}
