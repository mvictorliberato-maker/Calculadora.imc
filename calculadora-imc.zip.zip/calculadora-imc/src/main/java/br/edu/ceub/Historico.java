package br.edu.ceub;

import java.util.ArrayList;
import java.util.List;

public class Historico {

    private List<String> registros;

    public Historico() {
        registros = new ArrayList<>();
    }

    public void adicionarRegistro(String registro) {
        registros.add(registro);
    }

    public void exibirHistorico() {
        if (registros.isEmpty()) {
            System.out.println("Nenhum registro encontrado.");
            return;
        }
        System.out.println("\n===== HISTÓRICO =====");
        for (String registro : registros) {
            System.out.println(registro);
            System.out.println("---------------------");
        }
    }
}
