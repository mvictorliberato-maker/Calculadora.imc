package br.edu.ceub;

public class Pessoa extends PessoaBase implements CalculadoraIMC {

    private double peso;
    private double altura;
    private boolean ativo;

    public Pessoa(String nome, int idade, double peso, double altura) {
        super(nome, idade);
        this.peso = peso;
        this.altura = altura;
        this.ativo = true;
    }

    @Override
    public double calcularIMC(double peso, double altura) {
        return peso / CalculadoraRecursiva.potencia(altura, 2);
    }

    @Override
    public String classificarIMC(double imc) {
        if (imc < 18.5) {
            return "Abaixo do peso";
        } else if (imc < 25) {
            return "Peso normal";
        } else if (imc < 30) {
            return "Sobrepeso";
        } else if (imc < 35) {
            return "Obesidade Grau I";
        } else if (imc < 40) {
            return "Obesidade Grau II";
        } else {
            return "Obesidade Grau III";
        }
    }

    @Override
    public String exibirPerfil() {
        double imc = calcularIMC(peso, altura);
        return "Nome: " + getNome() +
                "\nIdade: " + getIdade() +
                "\nPeso: " + peso + " kg" +
                "\nAltura: " + altura + " m" +
                "\nIMC: " + String.format("%.2f", imc) +
                "\nClassificação: " + classificarIMC(imc);
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if (peso <= 0) {
            throw new EntradaInvalidaException("Peso deve ser positivo!");
        }
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        if (altura <= 0) {
            throw new EntradaInvalidaException("Altura deve ser positiva!");
        }
        this.altura = altura;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
}
