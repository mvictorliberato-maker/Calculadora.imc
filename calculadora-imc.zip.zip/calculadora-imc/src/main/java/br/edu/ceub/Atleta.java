package br.edu.ceub;

public class Atleta extends Pessoa {

    private String modalidade;

    public Atleta(String nome, int idade, double peso, double altura, String modalidade) {
        super(nome, idade, peso, altura);
        this.modalidade = modalidade;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    @Override
    public String classificarIMC(double imc) {
        if (imc < 20) {
            return "Abaixo do ideal para atleta";
        } else if (imc < 27) {
            return "Peso ideal para atleta";
        } else if (imc < 32) {
            return "Acima do ideal para atleta";
        } else {
            return "Obesidade para atleta";
        }
    }

    @Override
    public String exibirPerfil() {
        return super.exibirPerfil() + "\nModalidade: " + modalidade;
    }
}
