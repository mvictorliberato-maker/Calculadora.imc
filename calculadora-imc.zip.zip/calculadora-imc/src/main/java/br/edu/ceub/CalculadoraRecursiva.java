package br.edu.ceub;

public class CalculadoraRecursiva {

    // Recursão: calcula base^expoente sem usar Math.pow()
    public static double potencia(double base, int expoente) {
        if (expoente == 0) {
            return 1;
        }
        return base * potencia(base, expoente - 1);
    }

    // Função auxiliar não-recursiva: arredonda para 2 casas decimais
    public static double arredondar(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    // Função auxiliar não-recursiva: exibe separador visual no console
    public static void linha() {
        System.out.println("----------------------------------------");
    }
}
