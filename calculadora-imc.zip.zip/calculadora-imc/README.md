# Calculadora de IMC via CLI

Projeto de Sistematização da disciplina de **Programação Orientada a Objetos** — UniCEUB/CELUB.  
Implementa uma calculadora de Índice de Massa Corporal (IMC) via linha de comando, aplicando todos os pilares do paradigma OO.

---

## Pré-requisitos

- Java 17 ou superior
- Maven 3.8 ou superior

Verificar instalação:
```bash
java -version
mvn -version
```

---

## Como Compilar

```bash
mvn compile
```

---

## Como Executar

**Opção 1 — via Maven (desenvolvimento):**
```bash
mvn exec:java -Dexec.mainClass="br.edu.ceub.Main"
```

**Opção 2 — gerar JAR e executar:**
```bash
mvn package
java -jar target/calculadora-imc-1.0.0.jar
```

---

## Demonstração de Uso

```
----------------------------------------
      CALCULADORA DE IMC
----------------------------------------
[1] Cadastrar Pessoa
[2] Cadastrar Atleta
[3] Calcular IMC da última pessoa cadastrada
[4] Exibir Histórico
[0] Sair
----------------------------------------
Escolha: 1
Nome: João Silva
Idade: 25
Peso (kg): 75
Altura (m): 1.75
Pessoa cadastrada com sucesso!
Nome: João Silva | Idade: 25 | Peso: 75.0 kg | Altura: 1.75 m
IMC: 24.49 | Classificação: Peso normal

Escolha: 2
Nome: Ana Lima
Modalidade: Natação
...
IMC: 23.03 | Classificação: Peso ideal para atleta
```

---

## Estrutura do Projeto

```
calculadora-imc/
├── src/main/java/br/edu/ceub/
│   ├── CalculadoraIMC.java         ← interface (contrato)
│   ├── PessoaBase.java             ← classe abstrata
│   ├── Pessoa.java                 ← herança + encapsulamento + interface
│   ├── Atleta.java                 ← herança multinível + polimorfismo
│   ├── Historico.java              ← parte da composição
│   ├── SistemaIMC.java             ← composição + orquestração
│   ├── CalculadoraRecursiva.java   ← recursão (potência sem Math.pow)
│   ├── EntradaInvalidaException.java ← exceção personalizada
│   └── Main.java                   ← ponto de entrada + menu CLI
├── pom.xml                         ← gerenciamento de dependências (Maven)
└── README.md
```

---

## Conceitos de POO Aplicados

| Conceito | Onde aparece |
|---|---|
| Interface | `CalculadoraIMC` — contrato de `calcularIMC` e `classificarIMC` |
| Classe Abstrata | `PessoaBase` — método abstrato `exibirPerfil()` |
| Encapsulamento | Atributos `private` em `Pessoa` com getters/setters validados |
| Herança | `Pessoa extends PessoaBase` · `Atleta extends Pessoa` |
| Polimorfismo | `Atleta.classificarIMC()` sobrescreve `Pessoa.classificarIMC()` |
| Composição | `SistemaIMC` possui (`tem-um`) `Historico` |
| Recursão | `CalculadoraRecursiva.potencia()` — calcula altura² sem Math.pow |
| Exceções | `EntradaInvalidaException extends RuntimeException` + try/catch |

---

## Dependência Externa

**JUnit Jupiter 5.10.2** — framework de testes unitários para Java.  
Adicionado para permitir a escrita de testes automatizados que validam o cálculo do IMC e as classificações das classes `Pessoa` e `Atleta`.

---

## Autor

Projeto desenvolvido para a disciplina de Programação Orientada a Objetos — UniCEUB/CELUB · 2026
